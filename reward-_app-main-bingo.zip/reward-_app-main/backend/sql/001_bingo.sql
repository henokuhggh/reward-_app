-- ============================================================
-- Bingo feature migration
-- Run this once in the Supabase SQL editor (or via CLI) against
-- your existing project. It only ADDS new tables/functions - it
-- never touches users/deposits/withdrawals/app_settings etc.
--
-- It assumes the existing `users` table has: id (uuid pk),
-- balance (numeric), signup_bonus (numeric), referred_by (uuid,
-- fk -> users.id), has_deposited (boolean). These already exist
-- in this project (see register_user / purchase_product usage).
-- ============================================================

-- ----------------------------------------------------------
-- 1. Stake tiers (admin-configurable, replaces the old
--    hardcoded 10/20/50/100 list)
-- ----------------------------------------------------------
create table if not exists bingo_stake_tiers (
  id uuid primary key default gen_random_uuid(),
  amount numeric not null check (amount > 0),
  is_active boolean not null default true,
  sort_order int not null default 0,
  created_at timestamptz not null default now()
);

-- Seed the four tiers the user asked for, only if the table is empty
insert into bingo_stake_tiers (amount, sort_order)
select v.amount, v.sort_order
from (values (10, 1), (20, 2), (50, 3), (100, 4)) as v(amount, sort_order)
where not exists (select 1 from bingo_stake_tiers);

-- ----------------------------------------------------------
-- 2. Pre-made cartels (fixed 5x5 cards, numbered 1-100).
--    grid is a 25-element array in row-major order, standard
--    75-ball layout: col B(1-15) I(16-30) N(31-45, center free)
--    G(46-60) O(61-75). center cell = 0 (free space).
-- ----------------------------------------------------------
create table if not exists bingo_cartels (
  id int primary key,
  grid int[] not null,
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------
-- 3. Rounds. One round = one stake tier's current/next game.
--    status: waiting (needs >=2 players) -> active (drawing
--    numbers) -> finished.
-- ----------------------------------------------------------
create table if not exists bingo_rounds (
  id uuid primary key default gen_random_uuid(),
  stake_tier_id uuid not null references bingo_stake_tiers(id),
  stake_amount numeric not null,
  status text not null default 'waiting' check (status in ('waiting', 'active', 'finished', 'cancelled')),
  called_numbers int[] not null default '{}',
  total_pool numeric not null default 0,
  platform_cut numeric not null default 0,
  prize_pool numeric not null default 0,
  winner_ids uuid[] not null default '{}',
  win_pattern text,
  started_at timestamptz,
  finished_at timestamptz,
  created_at timestamptz not null default now()
);

create index if not exists idx_bingo_rounds_open
  on bingo_rounds (stake_tier_id, status)
  where status in ('waiting', 'active');

-- ----------------------------------------------------------
-- 4. Entries. One row per player per round. cartel_id is the
--    card they picked; marked_numbers tracks server-confirmed
--    marks (server is authoritative, not client taps) so a
--    tampered client can never fabricate a win.
-- ----------------------------------------------------------
create table if not exists bingo_entries (
  id uuid primary key default gen_random_uuid(),
  round_id uuid not null references bingo_rounds(id),
  user_id uuid not null references users(id),
  cartel_id int not null references bingo_cartels(id),
  amount_paid numeric not null,
  paid_from_bonus numeric not null default 0,
  paid_from_balance numeric not null default 0,
  is_winner boolean not null default false,
  payout numeric not null default 0,
  created_at timestamptz not null default now(),
  unique (round_id, user_id),
  unique (round_id, cartel_id)
);

create index if not exists idx_bingo_entries_round on bingo_entries (round_id);
create index if not exists idx_bingo_entries_user on bingo_entries (user_id);

-- ----------------------------------------------------------
-- 5. Referral earnings ledger (10 birr per referred signup).
--    Kept as its own table so it's auditable separately from
--    the bonus_releases/bonus_claims system that already exists.
-- ----------------------------------------------------------
create table if not exists referral_earnings (
  id uuid primary key default gen_random_uuid(),
  referrer_id uuid not null references users(id),
  referred_user_id uuid not null references users(id),
  amount numeric not null default 10,
  created_at timestamptz not null default now(),
  unique (referred_user_id)
);

-- ----------------------------------------------------------
-- 6. Platform earnings ledger (audit trail for the 20% cut
--    taken from every round's pool). Admin dashboard reads
--    SUM(amount) from here instead of recomputing from rounds.
-- ----------------------------------------------------------
create table if not exists platform_earnings (
  id uuid primary key default gen_random_uuid(),
  source text not null default 'bingo_cut',
  round_id uuid references bingo_rounds(id),
  amount numeric not null,
  created_at timestamptz not null default now()
);

-- ----------------------------------------------------------
-- 7. users table additions.
--    - signup_bonus_locked: true until the user wins any game,
--      then it flips false and the amount becomes normal balance.
--    - referral_earnings_total: running total, shown on Team page.
--    (guarded with IF NOT EXISTS-style checks via DO blocks so
--    this migration is safe to re-run)
-- ----------------------------------------------------------
do $$
begin
  if not exists (select 1 from information_schema.columns
                 where table_name = 'users' and column_name = 'signup_bonus_locked') then
    alter table users add column signup_bonus_locked boolean not null default true;
  end if;

  if not exists (select 1 from information_schema.columns
                 where table_name = 'users' and column_name = 'referral_earnings_total') then
    alter table users add column referral_earnings_total numeric not null default 0;
  end if;
end $$;

-- ============================================================
-- FUNCTIONS
-- ============================================================

-- ------------------------------------------------------------
-- credit_referral_bonus
-- Called right after register_user creates a new user with a
-- referrer. Pays the referrer 10 birr immediately (per the
-- product decision: referrer is paid at registration time, not
-- when the referred user deposits). Idempotent via the unique
-- constraint on referred_user_id.
-- ------------------------------------------------------------
create or replace function credit_referral_bonus(
  p_referrer_id uuid,
  p_referred_user_id uuid
) returns void
language plpgsql
as $$
begin
  insert into referral_earnings (referrer_id, referred_user_id, amount)
  values (p_referrer_id, p_referred_user_id, 10)
  on conflict (referred_user_id) do nothing;

  if found then
    update users
    set balance = balance + 10,
        referral_earnings_total = referral_earnings_total + 10
    where id = p_referrer_id;
  end if;
end;
$$;

-- ------------------------------------------------------------
-- get_open_round
-- Returns (creating if needed) the current waiting/active round
-- for a stake tier, along with live player count + pool total,
-- for the "cartel choosing page" summary view.
-- ------------------------------------------------------------
create or replace function get_open_round(p_stake_tier_id uuid)
returns table (
  round_id uuid,
  status text,
  stake_amount numeric,
  player_count bigint,
  total_pool numeric,
  prize_pool numeric
)
language plpgsql
as $$
declare
  v_round_id uuid;
  v_stake numeric;
begin
  select amount into v_stake from bingo_stake_tiers where id = p_stake_tier_id and is_active = true;
  if v_stake is null then
    raise exception 'Invalid or inactive stake tier';
  end if;

  select id into v_round_id
  from bingo_rounds
  where stake_tier_id = p_stake_tier_id
    and status in ('waiting', 'active')
  order by created_at asc
  limit 1;

  if v_round_id is null then
    insert into bingo_rounds (stake_tier_id, stake_amount, status)
    values (p_stake_tier_id, v_stake, 'waiting')
    returning id into v_round_id;
  end if;

  return query
  select
    r.id,
    r.status,
    r.stake_amount,
    (select count(*) from bingo_entries e where e.round_id = r.id),
    r.total_pool,
    r.prize_pool
  from bingo_rounds r
  where r.id = v_round_id;
end;
$$;

-- ------------------------------------------------------------
-- list_available_cartels
-- Cartels 1-100 not yet taken in the given round.
-- ------------------------------------------------------------
create or replace function list_available_cartels(p_round_id uuid)
returns table (cartel_id int)
language sql
stable
as $$
  select c.id
  from bingo_cartels c
  where not exists (
    select 1 from bingo_entries e
    where e.round_id = p_round_id and e.cartel_id = c.id
  )
  order by c.id;
$$;

-- ------------------------------------------------------------
-- join_bingo_round
-- Atomically: validates funds (bonus first, then balance, per
-- the existing purchase_product pattern), deducts them, takes
-- the platform's 20% cut into platform_earnings, and inserts
-- the entry. Locks the user row to prevent double-spend races,
-- and locks the round/cartel to prevent two players grabbing
-- the same card at once.
-- ------------------------------------------------------------
create or replace function join_bingo_round(
  p_user_id uuid,
  p_round_id uuid,
  p_cartel_id int
) returns table (
  entry_id uuid,
  new_balance numeric,
  new_signup_bonus numeric,
  round_status text
)
language plpgsql
as $$
declare
  v_user users%rowtype;
  v_round bingo_rounds%rowtype;
  v_stake numeric;
  v_from_bonus numeric := 0;
  v_from_balance numeric := 0;
  v_cut numeric;
  v_entry_id uuid;
  v_player_count bigint;
begin
  -- Lock the round row so pool totals / status can't race with
  -- another join or with the draw engine finishing the round.
  select * into v_round from bingo_rounds where id = p_round_id for update;
  if v_round.id is null then
    raise exception 'Round not found';
  end if;
  if v_round.status <> 'waiting' then
    raise exception 'This round has already started or ended';
  end if;

  if exists (select 1 from bingo_entries where round_id = p_round_id and cartel_id = p_cartel_id) then
    raise exception 'That cartel is already taken';
  end if;

  select * into v_user from users where id = p_user_id for update;
  if v_user.id is null then
    raise exception 'User not found';
  end if;

  v_stake := v_round.stake_amount;

  if exists (select 1 from bingo_entries where round_id = p_round_id and user_id = p_user_id) then
    raise exception 'You already joined this round';
  end if;

  -- Signup bonus (if still locked, it can still be SPENT on
  -- entries - it just can't be WITHDRAWN until a win) is used
  -- first, same pattern as purchase_product.
  if v_user.signup_bonus > 0 then
    v_from_bonus := least(v_user.signup_bonus, v_stake);
  end if;
  v_from_balance := v_stake - v_from_bonus;

  if v_from_balance > v_user.balance then
    raise exception 'Insufficient balance';
  end if;

  update users
  set signup_bonus = signup_bonus - v_from_bonus,
      balance = balance - v_from_balance
  where id = p_user_id;

  v_cut := round(v_stake * 0.20, 2);

  insert into bingo_entries (round_id, user_id, cartel_id, amount_paid, paid_from_bonus, paid_from_balance)
  values (p_round_id, p_user_id, p_cartel_id, v_stake, v_from_bonus, v_from_balance)
  returning id into v_entry_id;

  update bingo_rounds
  set total_pool = total_pool + v_stake,
      platform_cut = platform_cut + v_cut,
      prize_pool = prize_pool + (v_stake - v_cut)
  where id = p_round_id;

  insert into platform_earnings (source, round_id, amount)
  values ('bingo_cut', p_round_id, v_cut);

  select count(*) into v_player_count from bingo_entries where round_id = p_round_id;

  -- Needs >= 2 players before it can start. Starting itself is
  -- kicked off by the backend (which runs the draw timer), not
  -- here - this just reports back whether it's now startable.
  select * into v_user from users where id = p_user_id;

  return query select v_entry_id, v_user.balance, v_user.signup_bonus, v_round.status;
end;
$$;

-- ------------------------------------------------------------
-- start_bingo_round
-- Flips a waiting round to active once the backend decides to
-- start it (>= 2 players). Guarded so it can only fire once.
-- ------------------------------------------------------------
create or replace function start_bingo_round(p_round_id uuid)
returns void
language sql
as $$
  update bingo_rounds
  set status = 'active', started_at = now()
  where id = p_round_id and status = 'waiting';
$$;

-- ------------------------------------------------------------
-- call_bingo_number
-- Appends one drawn number to the round. Returns the updated
-- called_numbers so the backend can broadcast it. Raises if the
-- number was already called (defensive - backend shouldn't ask
-- twice, but this keeps the array free of dupes under a retry).
-- ------------------------------------------------------------
create or replace function call_bingo_number(p_round_id uuid, p_number int)
returns int[]
language plpgsql
as $$
declare
  v_called int[];
begin
  select called_numbers into v_called from bingo_rounds where id = p_round_id for update;
  if p_number = any(v_called) then
    return v_called;
  end if;
  update bingo_rounds
  set called_numbers = array_append(called_numbers, p_number)
  where id = p_round_id
  returning called_numbers into v_called;
  return v_called;
end;
$$;

-- ------------------------------------------------------------
-- finish_bingo_round
-- Pays out winners (prize pool split evenly among ties) and
-- closes the round. Also unlocks each winner's signup bonus
-- permanently, per the product decision. Idempotent: no-ops if
-- the round is already finished.
-- ------------------------------------------------------------
create or replace function finish_bingo_round(
  p_round_id uuid,
  p_winner_ids uuid[],
  p_win_pattern text
) returns void
language plpgsql
as $$
declare
  v_round bingo_rounds%rowtype;
  v_share numeric;
  v_winner_id uuid;
begin
  select * into v_round from bingo_rounds where id = p_round_id for update;
  if v_round.id is null or v_round.status = 'finished' then
    return;
  end if;

  if array_length(p_winner_ids, 1) > 0 then
    v_share := round(v_round.prize_pool / array_length(p_winner_ids, 1), 2);

    foreach v_winner_id in array p_winner_ids loop
      update bingo_entries
      set is_winner = true, payout = v_share
      where round_id = p_round_id and user_id = v_winner_id;

      -- Winning any game unlocks the 30 birr signup bonus
      -- permanently - it becomes ordinary withdrawable balance
      -- from here on. Both credits are folded into a single
      -- `balance = balance + ...` expression because Postgres
      -- evaluates every assignment in one SET clause against the
      -- pre-update row, not sequentially - writing `balance`
      -- twice in the same UPDATE would silently drop the first one.
      update users
      set balance = balance + v_share + case when signup_bonus_locked then signup_bonus else 0 end,
          signup_bonus_locked = false
      where id = v_winner_id;
    end loop;
  end if;

  update bingo_rounds
  set status = 'finished',
      finished_at = now(),
      winner_ids = coalesce(p_winner_ids, '{}'),
      win_pattern = p_win_pattern
  where id = p_round_id;
end;
$$;

-- ------------------------------------------------------------
-- cancel_bingo_round
-- Refunds everyone if a round has to be aborted (e.g. only ever
-- got 1 player and an admin cancels it, or a system error).
-- Reverses bonus/balance split exactly as paid, and reverses the
-- platform cut too so nothing is kept on a round that never ran.
-- ------------------------------------------------------------
create or replace function cancel_bingo_round(p_round_id uuid)
returns void
language plpgsql
as $$
declare
  v_round bingo_rounds%rowtype;
  v_entry record;
begin
  select * into v_round from bingo_rounds where id = p_round_id for update;
  if v_round.id is null or v_round.status in ('finished', 'cancelled') then
    return;
  end if;

  for v_entry in select * from bingo_entries where round_id = p_round_id loop
    update users
    set balance = balance + v_entry.paid_from_balance,
        signup_bonus = signup_bonus + v_entry.paid_from_bonus
    where id = v_entry.user_id;
  end loop;

  update bingo_rounds set status = 'cancelled', finished_at = now() where id = p_round_id;
end;
$$;

-- ------------------------------------------------------------
-- get_bingo_card
-- Returns a player's cartel grid + which of their numbers have
-- been called so far, for rendering their card in the round.
-- ------------------------------------------------------------
create or replace function get_bingo_card(p_round_id uuid, p_user_id uuid)
returns table (
  cartel_id int,
  grid int[],
  called_numbers int[]
)
language sql
stable
as $$
  select c.id, c.grid, r.called_numbers
  from bingo_entries e
  join bingo_cartels c on c.id = e.cartel_id
  join bingo_rounds r on r.id = e.round_id
  where e.round_id = p_round_id and e.user_id = p_user_id;
$$;

-- ------------------------------------------------------------
-- admin_bingo_stats
-- Powers a new admin dashboard card: total platform earnings
-- from bingo, rounds played, and current live rounds.
-- ------------------------------------------------------------
create or replace function admin_bingo_stats()
returns table (
  total_platform_earnings numeric,
  total_rounds_finished bigint,
  total_rounds_live bigint,
  total_wagered numeric
)
language sql
stable
as $$
  select
    coalesce((select sum(amount) from platform_earnings where source = 'bingo_cut'), 0),
    (select count(*) from bingo_rounds where status = 'finished'),
    (select count(*) from bingo_rounds where status in ('waiting', 'active')),
    coalesce((select sum(total_pool) from bingo_rounds), 0);
$$;
